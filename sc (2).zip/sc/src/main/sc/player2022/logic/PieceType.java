package sc.player2022.logic;

public enum PieceType {
    COCKLE(1),
    GULL(2),
    STARFISH(2),
    SEAL(3);

    public int value;

    PieceType(int value) {
        this.value = value;
    }
}
