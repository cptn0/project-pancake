package sc.player2022.logic.Utils;
import java.util.List;

import sc.player2022.logic.Move;


public class Sorting {
    public static List<Move> quickSort(List<Move> a, int l, int h) {
        int i = partition(a, l, h);
        if (l < i - 1) {
            quickSort(a, l, i - 1);
        }
        if (i < h) {
            quickSort(a, i, h);
        }
        return a;
    }

    static int partition(List<Move> a, int l, int h) {
        Move p = a.get((l + h) / 2);
        int i = l, j = h;
        while (i <= j) {
            while (a.get(i).getMoveType().value < p.getMoveType().value) { i++; }
            while (a.get(j).getMoveType().value > p.getMoveType().value) { j--; }

            if (i <= j) {
                swap(a, i, j);
                i++;
                j--;
            }
        }
        return i;
    }

    static final List<Move> swap(List<Move> a, int p1, int p2) {
        Move a1 = a.get(p1);
        a.set(p1, a.get(p2));
        a.set(p2, a1);
        return a;
    }
}
