package sc.player2022.logic.Utils;

import java.util.Random;

import kotlin.ULong;

public class Zobrist {
    public static long[][] ZOBRIST_TABLE = new long[9][64]; // [piece type][square]
    public static long SIDE = new Random().nextLong(); // Used for changing sides

    static {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 64; j++) {
                ZOBRIST_TABLE[i][j] = new Random().nextLong();
            }
        }
    }    
}

