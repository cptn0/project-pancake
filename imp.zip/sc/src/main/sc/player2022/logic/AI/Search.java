package sc.player2022.logic.AI;

import java.util.List;
import java.util.Objects;

import sc.player2022.logic.Board.BitBoard;
import sc.player2022.logic.TranspositionTable.TTEntry;
import sc.player2022.logic.TranspositionTable.TranspositionTable;
import sc.player2022.logic.Limits;
import sc.player2022.logic.Move;

public class Search {
    public static int maxSearchDepth;
    public static boolean waitForStop = false;
    public final static int INF = 999999;

    private static boolean stop;
    private static Move IDMove = null;
    private static int IDScore = 0;
    private static int selDepth;

    public static void itDeep() {
        int alpha = -INF;
        int beta = INF;
        int depth = 1;

        while (depth <= maxSearchDepth || waitForStop) {

            long elapsed = System.currentTimeMillis() - Limits.startTime;
            if (stop || elapsed >= Limits.timeAllocated / 2)
                break;

            negaMaxRoot(depth, alpha, beta);
        }
    }

    public static void negaMaxRoot(int depth, int alpha, int beta) {
        int value = -INF;
        List<Move> moves = BitBoard.getPossibleMoves(true);

        if (moves.size() == 1) {
            IDMove = moves.get(0);
            IDScore = 0;
            return;
        }

        Move bestMove = null;
        for (int i = 0; i < moves.size(); i++) {
            Move move = moves.get(i);

            BitBoard.applyMove(move);
            value = -negaMax(depth - 1, 1, -beta, -alpha, true);
            BitBoard.undoMove(move);

            if (stop || Limits.checkLimits()) {
                stop = true;
                break;
            }

            if (value > alpha) {
                bestMove = move;
                if (value >= beta) {
                    TranspositionTable.set(BitBoard.hash(), beta, depth, TTEntry.LOWER_BOUND, bestMove);
                    IDMove = bestMove;
                    IDScore = beta;
                    return;
                }
                alpha = value;
                TranspositionTable.set(BitBoard.hash(), alpha, depth, TTEntry.UPPER_BOUND, bestMove);
            }
        }

        if (bestMove == null)
            bestMove = moves.get(0);

        if (!stop) {
            TranspositionTable.set(BitBoard.hash(), alpha, depth, TTEntry.EXACT, bestMove);
            IDMove = bestMove;
            IDScore = alpha;
        }
    }

    public static int negaMax(int depth, int ply, int alpha, int beta, boolean canApplyNull) {
        int mateValue = INF -ply;

        int ttFlag = TTEntry.UPPER_BOUND;
        int reducedDepth;

        if (stop || Limits.checkLimits()) {
            stop = true;
            return 0;
        }

        if (alpha < -mateValue) alpha = -mateValue;
        if (beta > mateValue - 1) beta = mateValue - 1;
        if (alpha >= beta) {
            return alpha;
        }

        if (depth <= 0) return qSearch(depth, ply, alpha, beta);

        final TTEntry ttEntry = TranspositionTable.probe(BitBoard.hash());
        if (ttEntry != null && ttEntry.depth() >= depth) {
            switch (ttEntry.flag()) {
                case TTEntry.EXACT:
                    return ttEntry.score();

                case TTEntry.LOWER_BOUND:
                    alpha = Math.max(alpha, ttEntry.score());
                    break;

                case TTEntry.UPPER_BOUND:
                    beta = Math.min(beta, ttEntry.score());
                    break;
            }

            if (alpha >= beta) {
                return ttEntry.score();
            }
        }

        List<Move> moves = BitBoard.getPossibleMoves(true);
        int value;
        Move bestMove = null;

        for (int i = 0; i < moves.size(); i++) {
            Move move = moves.get(i);

            reducedDepth = depth;

            BitBoard.applyMove(move);
            value = -negaMax(reducedDepth - 1, ply + 1, -beta, -alpha, true);
            BitBoard.undoMove(move);

            if (stop) return 0;

            if (value > alpha) {
                bestMove = move;
                if (value >= beta) {
                    ttFlag = TTEntry.LOWER_BOUND;
                    alpha = beta;
                    break;
                }
                ttFlag = TTEntry.EXACT;
                alpha = value;
            }
        }

        if (bestMove != null && !stop) TranspositionTable.set(BitBoard.hash(), alpha, depth, ttFlag, bestMove);

        return alpha;
    }

    public static int qSearch(int depth, int ply, int alpha, int beta) {
        if (stop || Limits.checkLimits()) {
            stop = true;
            return 0;
        }
        selDepth = Math.max(ply, selDepth);

        int value = Evaluation.evaluate();

        if (value >= beta) {
            return beta;
        }

        if (alpha < value)
            alpha = value;

        List<Move> moves = BitBoard.getPossibleMoves(false);
        for (int i = 0; i < moves.size(); i++) {
            Move move = moves.get(i);

            BitBoard.applyMove(move);
            value = -qSearch(depth - 1, ply + 1, -beta, -alpha);
            BitBoard.undoMove(move);

            if (stop)
                return 0;

            if (value > alpha) {
                if (value >= beta) {
                    return beta;
                }
                alpha = value;
            }
        }
        return alpha;
    }

    public static Move getMove() {
        return IDMove;
    }

    public static int getScore() {
        return IDScore;
    }

    public static void stop() {
        stop = true;
    }
}
