package sc.player2022.logic.AI;

import java.util.concurrent.atomic.AtomicBoolean;

import sc.player2022.logic.Limits;
import sc.player2022.logic.Move;
import sc.player2022.logic.TranspositionTable.TranspositionTable;

public class SearchThread implements Runnable {
    private final AtomicBoolean running = new AtomicBoolean(false);
    
    public void startSearch() {
        Thread worker = new Thread(this);
        worker.start();
    }

    public void run() {
        running.set(true);
        Search.itDeep();
        System.out.println("info score cp " + Search.getScore());
        System.out.println("bestmove " + Search.getMove());
        TranspositionTable.reset();
        System.gc();
        Limits.resetTime();
        running.set(false);
    }

    public Move getMove() {
        return Search.getMove();
    }

    public int getScore() {
        return Search.getScore();
    }

    public void stop() {
        Search.stop();
        Search.waitForStop = false;
        TranspositionTable.reset();
        System.gc();
        Limits.resetTime();
        running.set(false);
    }
}
