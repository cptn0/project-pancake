package sc.player2022.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sc.api.plugins.IGameState;
import sc.api.plugins.Team;
import sc.player.IGameHandler;
import sc.player2022.logic.AI.Search;
import sc.player2022.logic.AI.SearchThread;
import sc.player2022.logic.Board.BitBoard;
import sc.player2022.logic.Board.BitBoardInit;
import sc.plugin2022.Coordinates;
import sc.plugin2022.GameState;
import sc.plugin2022.Piece;
import sc.plugin2022.Vector;
import sc.shared.GameResult;


/**
 * Das Herz des Clients:
 * Eine sehr simple Logik, die ihre Zuege zufaellig waehlt,
 * aber gueltige Zuege macht.
 * <p>
 * Ausserdem werden zum Spielverlauf Konsolenausgaben gemacht.
 */
public class Logic implements IGameHandler {
  static final Logger log = LoggerFactory.getLogger(Logic.class);

  static final int DEFAULT_MAX_SEARCH_DEPTH = 99;

  /** Aktueller Spielstatus. */
  GameState gameState;
  private final static SearchThread thread = new SearchThread();

  
  public void onGameOver(GameResult data) {
    log.info("Das Spiel ist beendet, Ergebnis: {}", data);
  }
  @Override
  public sc.plugin2022.Move calculateMove() {

    Search.maxSearchDepth = DEFAULT_MAX_SEARCH_DEPTH;
    Search.waitForStop = false;
    int depth;
    long moveTime;
    boolean infiniteFlag;

    if (gameState.getTurn() == (gameState.getCurrentTeam() == Team.ONE ? 0 : 1))
      initBoard();

    thread.startSearch();



    Coordinates coordinates = new Coordinates(m.getFromX(), m.getFromY());
    Vector vector = new Vector(m.getFromX() - coordinates.getX(), m.getFromY() - coordinates.getY());
      
    sc.plugin2022.Move move = sc.plugin2022.Move.create(coordinates, vector);
    return move;
  }

  @Override
  public void onUpdate(IGameState gameState) {
    this.gameState = (GameState) gameState;
    log.info("Zug: {} Dran: {}", gameState.getTurn(), gameState.getCurrentTeam());
    sc.plugin2022.Move lastMove = this.gameState.getLastMove();

    if (gameState.getTurn() > (gameState.getCurrentTeam() == Team.ONE ? 0 : 1)) {
      long from = BitBoardInit.integersToBitBoard(lastMove.getFrom().getX(), lastMove.getFrom().getY());
      long to = BitBoardInit.integersToBitBoard(lastMove.getTo().getX(), lastMove.getTo().getY());
      BitBoard.applyMove(BitBoard.createMove(from, to));   
    }
  }

  @Override
  public void onError(String error) {
    log.warn("Fehler: {}", error);
  }

  void initBoard() {
    String stringBoard[][] = {
      {" ", " ", " ", " ", " ", " ", " ", " "},
      {" ", " ", " ", " ", " ", " ", " ", " "},
      {" ", " ", " ", " ", " ", " ", " ", " "},
      {" ", " ", " ", " ", " ", " ", " ", " "},
      {" ", " ", " ", " ", " ", " ", " ", " "},
      {" ", " ", " ", " ", " ", " ", " ", " "},
      {" ", " ", " ", " ", " ", " ", " ", " "},
      {" ", " ", " ", " ", " ", " ", " ", " "}};

    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        Piece p = gameState.getBoard().get(i, j);
        if (p != null) {
          switch (p.getType()) {
            case Herzmuschel:
              stringBoard[j][i] = (p.getTeam() == Team.ONE ? "C" : "c");
              break;

            case Moewe:
              stringBoard[j][i] = (p.getTeam() == Team.ONE ? "G" : "g");
              break;

            case Robbe:
              stringBoard[j][i] = (p.getTeam() == Team.ONE ? "S" : "s");
              break;

            case Seestern:
              stringBoard[j][i] = (p.getTeam() == Team.ONE ? "F" : "f");
              break;

            default:
              System.err.println("Something went wrong!");
          }
        }
      }
    }
    

    if (gameState.getTurn() > 0) BitBoardInit.initBitBoard(stringBoard, 1, BitBoard.GameState.otherColor());
    else BitBoardInit.initBitBoard(stringBoard, 0, BitBoard.GameState.currentColor());
  }
}
