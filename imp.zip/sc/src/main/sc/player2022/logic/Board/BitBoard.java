package sc.player2022.logic.Board;

import java.util.ArrayList;
import java.util.List;

import sc.player2022.logic.Move;
import sc.player2022.logic.PieceType;
import sc.player2022.logic.Move.MoveType;
import sc.player2022.logic.Utils.Sorting;
import sc.player2022.logic.Utils.Zobrist;

public class BitBoard {
    
    public static int[] pieceCount = {2, 2, 2, 2, 2, 2, 2, 2};
    public static long[] pieceBoards = {0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L};
    public static long rPieces, bPieces, stacks;
    
    static final long FILE_MASKS[] = { 0x101010101010101L, 0x202020202020202L, 0x404040404040404L, 0x808080808080808L,
        0x1010101010101010L, 0x2020202020202020L, 0x4040404040404040L, 0x8080808080808080L };

    static long hash;

    public static class GameState {
        public static enum Color {
            RED, BLUE;
        }

        static int rScore = 0, bScore = 0;
        
        protected static Color currentColor = Color.RED;
        protected static int turn = 0;

       
        public static int turn() { return turn; }
       
        public static Color currentColor() { return currentColor; }
       
        public static Color otherColor() { return (currentColor == Color.RED ? Color.BLUE : Color.RED); }
       
        public static int score(Color c) { return (c == Color.RED ? rScore : bScore); }
    }

    public static long getPieceBoard(PieceType p, int c) {
        return pieceBoards[c * 4 + p.ordinal()];
    }
    
    public static List<Move> getPossibleMoves(boolean includeQuietMoves) {
        List<Move> moves = new ArrayList<Move>();

        for (int i = 0; i < 4; i++) {
            // The bitboard with the current index
            long pieceBoard = pieceBoards[i + (GameState.currentColor == GameState.Color.RED ? 0 : 4)];
            
            /*
            * Loop through all pieces in the bitboard
            */
            while (pieceBoard != 0) {
                
                int pieceIsolated = Long.numberOfTrailingZeros(pieceBoard & -pieceBoard); // Get the bit position
                long from = pieceBoard & (1L << pieceIsolated);
                
                // List of bitboards with all possible destinations for a piece after it has moved
                Long moveBoard = 0L;
                
                /*
                * Choose the right shift for the current pieceboard
                */
                switch (i) {
                    case 0: // 0 - Cockle
                    moveBoard = getCockleMoves(from, GameState.currentColor); 
                    break;
                    case 1: // 1 - Gull
                    moveBoard = getGullMoves(from); 
                    break;
                    case 2: // 2 - Starfish
                    moveBoard = getStarfishMoves(from, GameState.currentColor); 
                    break;
                    case 3: // 3 - Seal
                    moveBoard = getSealMoves(from); 
                    break;
                    
                    default: System.err.println("Something went wrong!");
                }

                /*
                * Loop through all positions the piece could move to 
                */
                while (moveBoard != 0) {
                    
                    int moveIsolated = Long.numberOfTrailingZeros(moveBoard & -moveBoard);
                    long to = moveBoard & (1L << moveIsolated);
                    
                    Move m = createMove(from, to);
                    if (m != null) // Move is valid 
                        if ((includeQuietMoves == false && m.getMoveType() != MoveType.NORMAL) || includeQuietMoves)
                            moves.add(m);
                    
                    moveBoard &= moveBoard - 1; // Get the next move from the moveBoard
                }
                pieceBoard &= pieceBoard - 1; // Get the next piece from the pieceBoard
            }
        }
        
        if (moves.size() > 1) 
            Sorting.quickSort(moves, 0, moves.size() - 1);
        
        return moves;
    }

    public static Move createMove(long from, long to) {
        if ((to & (GameState.currentColor == GameState.Color.RED ? rPieces : bPieces)) != 0)
            return null; // Invalid move
        
        // else
        int index = 0;
        for (;; index++) // Get the index of the piece        
            if ((pieceBoards[index] & from) != 0) break; //! runs endless if move is invalid
        
        boolean capture = false, promotion = false, rStack = false, bStack = false;
        if (index < 4) {
            if ((from & stacks) != 0)
                rStack = true;

            if ((to & stacks) != 0)
                bStack = true;
        } else {
            if ((from & stacks) != 0)
                bStack = true;

            if ((to & stacks) != 0)
                rStack = true;
        }

        if ((to & (bPieces | rPieces)) != 0) 
            capture = true;

        if ((to & FILE_MASKS[index < 4 ? 7 : 0]) != 0) 
            promotion = true;

        /*
         * Return move with the right movetype 
         */    
        if (capture) {
            int captureIndex = 0;
            for (;; captureIndex++) // Get the index of the captured piece
                if ((pieceBoards[captureIndex] & to) != 0) break;

            if (promotion) {
                if (rStack && bStack)
                    return Move.create(from, to, MoveType.DOUBLE_SCORE_RB_STACK, index, captureIndex);

                if (rStack)
                    return Move.create(from, to, MoveType.DOUBLE_SCORE_R_STACK, index, captureIndex);

                if (bStack)
                    return Move.create(from, to, MoveType.DOUBLE_SCORE_B_STACK, index, captureIndex);

                // else    
                return Move.create(from, to, MoveType.SCORE_PROMOTION, index, captureIndex);
            }

            if (rStack && bStack)
                return Move.create(from, to, MoveType.SCORE_RB_STACK, index, captureIndex);

            if (rStack)
                return Move.create(from, to, MoveType.SCORE_R_STACK, index, captureIndex);

            if (bStack)
                return Move.create(from, to, MoveType.SCORE_B_STACK, index, captureIndex);

            // else
            return Move.create(from, to, MoveType.CAPTURE, index, captureIndex);
        }

        if (promotion) {
            if (rStack || bStack)
                return Move.create(from, to, MoveType.SCORE_STACK_PROMOTION, index);

            // else
            return Move.create(from, to, MoveType.SCORE_PROMOTION, index);
        }

        return Move.create(from, to, MoveType.NORMAL, index);
    }

    public static void applyMove(Move m) {
        Long start = m.getLongStart();
        long dest = m.getLongDestination();
        
        int i = m.getPieceIndex();
        int i2 = m.getCapturePieceIndex();

        int sqFrom = getSquare(m.getFromX(), m.getFromY());
        int sqTo = getSquare(m.getToX(), m.getToY());

        switch (m.getMoveType()) {
            case NORMAL:
                pieceBoards[i] ^= start | dest;

                if ((start & stacks) != 0)
                    stacks ^= start | dest;

                if (i < 4) 
                    rPieces ^= start | dest; // i piece is red
                
                else bPieces ^= start | dest; // i piece is blue

                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i][sqTo];
                break;

            case CAPTURE:
                pieceBoards[i] ^= start | dest;
                pieceBoards[i2] ^= dest;
                
                stacks |= dest;

                if (i < 4) { // i piece is red
                    rPieces ^= start | dest;
                    bPieces ^= dest;
                } else { // i piece is blue
                    bPieces ^= start | dest;
                    rPieces ^= dest;
                }

                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i][sqTo] |
                    Zobrist.ZOBRIST_TABLE[i2][sqTo] | Zobrist.ZOBRIST_TABLE[9][sqTo];
                break;

            case SCORE_R_STACK:
                pieceBoards[i] ^= start;
                pieceBoards[i2] ^= dest;

                if (i < 4) { // i piece is red
                    rPieces ^= start;
                    bPieces ^= dest;
                    stacks ^= start;

                    GameState.rScore++;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqFrom];        
                } else { // i piece is blue
                    bPieces ^= start;
                    rPieces ^= dest;
                    stacks ^= dest;

                    GameState.bScore++;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqTo];
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo];
                break;

            case SCORE_B_STACK:
                pieceBoards[i] ^= start;
                pieceBoards[i2] ^= dest;

                if (i < 4) { // i piece is red
                    rPieces ^= start;
                    bPieces ^= dest;
                    stacks ^= dest;

                    GameState.rScore++;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqTo];
                } else { // i piece is blue
                    bPieces ^= start;
                    rPieces ^= dest;
                    stacks ^= start;

                    GameState.bScore++;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqFrom];
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo];
                break;

            case SCORE_RB_STACK:
                pieceBoards[i] ^= start;
                pieceBoards[i2] ^= dest;

                stacks ^= start | dest;

                if (i < 4) { // i piece is red
                    rPieces ^= start;
                    bPieces ^= dest;

                    GameState.rScore++;
                } else { // i piece is blue
                    bPieces ^= start;
                    rPieces ^= dest;

                    GameState.bScore++;
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo] |
                    Zobrist.ZOBRIST_TABLE[9][sqFrom] | Zobrist.ZOBRIST_TABLE[9][sqTo];
                break;

            case SCORE_PROMOTION:
                pieceBoards[i] ^= start;

                if (i < 4) { // i piece is red
                    rPieces ^= start;

                    GameState.rScore++;
                } else { // i piece is blue
                    bPieces ^= start;

                    GameState.bScore++;
                }

                if (i2 < 8) { // promotion with capture
                    pieceBoards[i2] ^= dest;
                    
                    if (i2 < 4) rPieces ^= dest; // i2 piece is red
                    else bPieces ^= dest; // i2 piece is blue

                    hash ^= Zobrist.ZOBRIST_TABLE[i2][sqTo];
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom];
                break;

            case SCORE_STACK_PROMOTION: // always without capture (otherwise it would be a double score)
                pieceBoards[i] ^= start;

                stacks ^= start;

                if (i < 4) { // i piece is red
                    rPieces ^= start;

                    GameState.rScore++;
                } else { // i piece is blue
                    bPieces ^= start;

                    GameState.bScore++;
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[9][sqFrom];
                break;
            
            case DOUBLE_SCORE_R_STACK:
                pieceBoards[i] ^= start;
                pieceBoards[i2] ^= dest;

                if (i < 4) { // i piece is red
                    rPieces ^= start;
                    bPieces ^= dest;
                    stacks ^= start;

                    GameState.rScore += 2;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqFrom];
                } else { // i piece is blue
                    bPieces ^= start;
                    rPieces ^= dest;
                    stacks ^= dest;

                    GameState.bScore += 2;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqTo];
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo];
                break;

            case DOUBLE_SCORE_B_STACK:
                pieceBoards[i] ^= start;
                pieceBoards[i2] ^= dest;

                if (i < 4) { // i piece is red
                    rPieces ^= start;
                    bPieces ^= dest;
                    stacks ^= dest;

                    GameState.rScore += 2;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqTo];
                } else { // i piece is blue
                    bPieces ^= start;
                    rPieces ^= dest;
                    stacks ^= start;

                    GameState.bScore += 2;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqFrom];
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo];
                break;

            case DOUBLE_SCORE_RB_STACK:
                pieceBoards[i] ^= start;
                pieceBoards[i2] ^= dest;

                stacks ^= start | dest;

                if (i < 4) { // i piece is red
                    rPieces ^= start;
                    bPieces ^= dest;

                    GameState.rScore += 2;
                } else { // i piece is blue
                    bPieces ^= start;
                    rPieces ^= dest;

                    GameState.bScore += 2;
                } 
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo] |
                    Zobrist.ZOBRIST_TABLE[9][sqFrom] | Zobrist.ZOBRIST_TABLE[9][sqTo];
                break;
        }

        GameState.currentColor = GameState.otherColor();
        GameState.turn++;
        
        hash ^= Zobrist.SIDE;
    }

    public static void undoMove(Move m) {
        long start = m.getLongStart();
        Long dest = m.getLongDestination();

        int i = m.getPieceIndex();
        int i2 = m.getCapturePieceIndex();

        int sqFrom = getSquare(m.getFromX(), m.getFromY());
        int sqTo = getSquare(m.getToX(), m.getToY());

        switch (m.getMoveType()) {
            case NORMAL:
                pieceBoards[i] ^= start | dest;

                if ((stacks & dest) != 0)
                    stacks ^= dest | start;

                if (i < 4)
                    rPieces ^= start | dest; // i piece is red
                
                else bPieces ^= start | dest; // i piece is blue

                hash  ^= Zobrist.ZOBRIST_TABLE[i][sqTo] | Zobrist.ZOBRIST_TABLE[i][sqFrom];
                break;

            case CAPTURE:
                pieceBoards[i] ^= start | dest;
                pieceBoards[i2] |= dest;

                stacks ^= dest;

                if (i < 4) { // i piece is red
                    rPieces ^= start | dest;
                    bPieces |= dest;
                } else { // i piece is blue
                    bPieces ^= start | dest;
                    rPieces |= dest;
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqTo] | Zobrist.ZOBRIST_TABLE[i][sqFrom] |
                    Zobrist.ZOBRIST_TABLE[i2][sqTo] | Zobrist.ZOBRIST_TABLE[9][sqTo];
                break;

            case SCORE_R_STACK: 
                pieceBoards[i] |= start;
                pieceBoards[i2] |= dest;

                if (i < 4) { // i piece is red
                    rPieces |= start;
                    bPieces |= dest;
                    stacks |= start;

                    GameState.rScore--;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqFrom];
                } else { //i piece is blue
                    bPieces |= start;
                    rPieces |= dest;
                    stacks |= dest;

                    GameState.bScore--;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqTo];
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo];
                break;

            case SCORE_B_STACK:
                pieceBoards[i] |= start;
                pieceBoards[i2] |= dest;

                if (i < 4) { // i piece is red
                    rPieces |= start;
                    bPieces |= dest;
                    stacks |= dest;

                    GameState.rScore--;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqTo];
                } else { // i piece is blue
                    bPieces |= start;
                    rPieces |= dest;
                    stacks |= start;

                    GameState.bScore--;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqFrom];
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo];
                break;

            case SCORE_RB_STACK:
                pieceBoards[i] |= start;
                pieceBoards[i2] |= dest;

                stacks |= start | dest; 

                if (i < 4) { // i piece is red
                    rPieces |= start;
                    bPieces |= dest;

                    GameState.rScore--;
                } else { // i piece is blue
                    bPieces |= start;
                    rPieces |= dest;

                    GameState.bScore--;
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo] |
                    Zobrist.ZOBRIST_TABLE[9][sqFrom] | Zobrist.ZOBRIST_TABLE[9][sqTo];
                break;

            case SCORE_PROMOTION:
                pieceBoards[i] |= start;

                if (i < 4) { // i piece is red
                    rPieces |= start;

                    GameState.rScore--;
                } else { // i piece is blue
                    bPieces |= start;

                    GameState.bScore--;
                }

                if (i2 < 8) { // promotion with capture
                    pieceBoards[i2] |= dest;
                    
                    if (i2 < 4) rPieces |= dest; // i2 piece is red
                    else bPieces |= dest; // i2 piece is blue

                    hash ^= Zobrist.ZOBRIST_TABLE[i2][sqTo];
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom];
                break;

            case SCORE_STACK_PROMOTION: // always without capture (otherwise it would be a double score)
                pieceBoards[i] |= start;

                stacks |= start;

                if (i < 4) { // i piece is red
                    rPieces |= start;

                    GameState.rScore--;
                } else { // i piece is blue
                    bPieces |= start;

                    GameState.bScore--;
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[9][sqFrom];
                break;
            
            case DOUBLE_SCORE_R_STACK:
                pieceBoards[i] |= start;
                pieceBoards[i2] |= dest;

                if (i < 4) { // i piece is red
                    rPieces |= start;
                    bPieces |= dest;
                    stacks |= start;

                    GameState.rScore -= 2;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqFrom];
                } else { // i piece is blue
                    bPieces |= start;
                    rPieces |= dest;
                    stacks |= dest;

                    GameState.bScore -= 2;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqTo];
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo];
                break;

            case DOUBLE_SCORE_B_STACK:
                pieceBoards[i] |= start;
                pieceBoards[i2] |= dest;

                if (i < 4) { // i piece is red
                    rPieces |= start;
                    bPieces |= dest;
                    stacks |= dest;

                    GameState.rScore -= 2;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqTo];
                } else { // i piece is blue
                    bPieces |= start;
                    rPieces |= dest;
                    stacks |= start;

                    GameState.bScore -= 2;

                    hash ^= Zobrist.ZOBRIST_TABLE[9][sqFrom];
                }
               
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo];
                break;

            case DOUBLE_SCORE_RB_STACK:
                pieceBoards[i] |= start;
                pieceBoards[i2] |= dest;

                stacks |= start | dest;

                if (i < 4) { // i piece is red
                    rPieces |= start;
                    bPieces |= dest;

                    GameState.rScore -= 2;
                } else { // i piece is blue
                    bPieces |= start;
                    rPieces |= dest;

                    GameState.bScore -= 2;
                }
                
                hash ^= Zobrist.ZOBRIST_TABLE[i][sqFrom] | Zobrist.ZOBRIST_TABLE[i2][sqTo] |
                    Zobrist.ZOBRIST_TABLE[9][sqFrom] | Zobrist.ZOBRIST_TABLE[9][sqTo];
                break;
        }

        GameState.currentColor = GameState.otherColor();
        GameState.turn--;

        hash ^= Zobrist.SIDE;
    }

    public static long hash() {
        return hash;
    }

    public static int getSquare(int x, int y) { return x + 8 * y; }

    public static Long getGullMoves(Long b) {
        return (b << 8 | b >>> 8 | (b << 1) & ~72340172838076673L | (b >>> 1) & ~-9187201950435737472L);
    }

    public static Long getSealMoves(long b) {
        return ((b << 6) & ~-4557430888798830400L) | ((b >>> 6) & ~217020518514230019L) | 
          ((b << 10) & ~217020518514230019L) | ((b >>> 10) & ~-4557430888798830400L) |
          ((b << 15) & ~-9187201950435737472L) | ((b >>> 15) & ~72340172838076673L) |
          ((b << 17) & ~72340172838076673L) | ((b >>> 17) & ~-9187201950435737472L);
    }
    
    public static Long getCockleMoves(Long b, GameState.Color c) {
        return (c == GameState.Color.RED ? ((b << 9) & ~72340172838076673L) | ((b >>> 7) & ~72340172838076673L) :
            (b << 7) & ~-9187201950435737472L | (b >>> 9) & ~-9187201950435737472L);
    }
    
    public static Long getStarfishMoves(long b, GameState.Color c) {
        return (b << 9) & ~72340172838076673L | (b >>> 7) & ~72340172838076673L | (b << 7) &
            ~-9187201950435737472L | (b >>> 9) & ~-9187201950435737472L | (c == GameState.Color.RED ? (b << 1) &
            ~72340172838076673L : (b >>> 1) & ~-9187201950435737472L);
    }
}