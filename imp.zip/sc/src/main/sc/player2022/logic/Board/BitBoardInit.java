package sc.player2022.logic.Board;

public class BitBoardInit {

    public static void initBitBoard() {
        String StringBoard[][] = {
            {"C", " ", " ", " ", " ", " ", " ", "s"},
            {"F", " ", " ", " ", " ", " ", " ", "s"},
            {"C", " ", " ", " ", " ", " ", " ", "g"},
            {"F", " ", " ", " ", " ", " ", " ", "g"},
            {"G", " ", " ", " ", " ", " ", " ", "f"},
            {"G", " ", " ", " ", " ", " ", " ", "c"},
            {"S", " ", " ", " ", " ", " ", " ", "f"},
            {"S", " ", " ", " ", " ", " ", " ", "c"}};

        arrayToBitBoard(StringBoard);
    }

    public static void initBitBoard(String[][] stringBoard, int turn, BitBoard.GameState.Color currentColor) {
        arrayToBitBoard(stringBoard);

        BitBoard.GameState.turn = turn;
        BitBoard.GameState.currentColor = currentColor;
    }
    
    public static long integersToBitBoard(int x, int y) {
        String binary = "0000000000000000000000000000000000000000000000000000000000000000";
        return stringToBitboard(binary.substring(8 * y + x + 1) + "1" + binary.substring(0, 8 * y + x));
    }
    
    static void arrayToBitBoard(String[][] chessBoard) {
        long RS = 0L, RF = 0L, RG = 0L, RC = 0L, BS = 0L, BF = 0L, BG = 0L, BC = 0L;
        String binary; // Stores the binary string that represents the specific bitboard
        for (int i = 0; i < 64; i++) {
            binary = "0000000000000000000000000000000000000000000000000000000000000000";
            binary = binary.substring(i + 1) + "1" + binary.substring(0, i);
            switch (chessBoard[i / 8][i % 8]) {
                case "S": 
                    RS += stringToBitboard(binary);
                    break;
                case "F":
                    RF += stringToBitboard(binary);
                    break;
                case "G": 
                    RG += stringToBitboard(binary);
                    break;
                case "C":
                    RC += stringToBitboard(binary);
                    break;
                case "s": 
                    BS += stringToBitboard(binary);
                    break;
                case "f":
                    BF += stringToBitboard(binary);
                    break;
                case "g": 
                    BG += stringToBitboard(binary);
                    break;
                case "c":
                    BC += stringToBitboard(binary);
                    break;
            }
        }

        BitBoard.pieceBoards[0] = RC;
        BitBoard.pieceBoards[1] = RG;
        BitBoard.pieceBoards[2] = RF;
        BitBoard.pieceBoards[3] = RS;
        BitBoard.rPieces = RC | RG | RF | RS;
        
        BitBoard.pieceBoards[4] = BC;
        BitBoard.pieceBoards[5] = BG;
        BitBoard.pieceBoards[6] = BF;
        BitBoard.pieceBoards[7] = BS;
        BitBoard.bPieces = BC | BG | BF | BS;
    }

    static long stringToBitboard(String binaryString) {
        if (binaryString.charAt(0) == '0') return Long.parseLong(binaryString, 2);
        
        return Long.parseLong("1" + binaryString.substring(2), 2) * 2;
    }
}
