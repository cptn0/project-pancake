package sc.player2022.logic;

public class Move {
    
    public enum MoveType {
        NORMAL(3), CAPTURE(2), SCORE_R_STACK(1), SCORE_B_STACK(1), SCORE_RB_STACK(1),
        SCORE_PROMOTION(1), SCORE_STACK_PROMOTION(1), DOUBLE_SCORE_R_STACK(0),
        DOUBLE_SCORE_B_STACK(0), DOUBLE_SCORE_RB_STACK(0);

        public int value;

        MoveType(int value) {
            this.value = value;
        }
    }

    long start, destination;
    int pieceIndex, capturePieceIndex;
    MoveType moveType; 

    public final static Move nullMove = new Move(0L, 0L, null, 0, 0);

    public Move(Long start, Long destination, MoveType moveType, int pieceIndex, int capturePieceIndex) {
        this.start = start;
        this.destination = destination;
        this.moveType = moveType;
        this.pieceIndex = pieceIndex;
        this.capturePieceIndex = capturePieceIndex;
    }

    
    public int getFromX() { return Long.numberOfTrailingZeros(start) % 8; }

    public int getFromY() { return Long.numberOfTrailingZeros(start) / 8; }

    public int getToX() { return Long.numberOfTrailingZeros(destination) % 8; }

    public int getToY() { return Long.numberOfTrailingZeros(destination) / 8; }

    public Long getLongStart() { return start; }

    public Long getLongDestination() { return destination; }

    public int getPieceIndex() { return pieceIndex; }
    
    public int getCapturePieceIndex() { return capturePieceIndex; }
    
    public MoveType getMoveType() { return moveType; }
    
    public static Move create(Long start, Long destination, MoveType moveType, int pieceIndex, int capturePieceIndex) {
        return new Move(start, destination, moveType, pieceIndex, capturePieceIndex);
    }

    public static Move create(Long start, Long destination, MoveType moveType, int pieceIndex) {
        return new Move(start, destination, moveType, pieceIndex, 100);
    }
}
