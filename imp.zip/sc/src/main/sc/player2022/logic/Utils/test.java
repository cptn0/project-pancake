package sc.player2022.logic.Utils;

public class test {
    public static void main(String[] args) {
        int p = 0;
        for (int i = 0; i < 64; i++) {
            for (int j = 0; j < 8; j++) {
                p++;
            }
        }
        System.out.println(p);

        int z = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 64; j++) {
                z++;
            }
        }
        System.out.println(z);
    }
}
