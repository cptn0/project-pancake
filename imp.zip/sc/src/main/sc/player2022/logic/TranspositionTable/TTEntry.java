package sc.player2022.logic.TranspositionTable;

import sc.player2022.logic.Move;

public class TTEntry {
    public final static byte EXACT = 0, LOWER_BOUND = 1, UPPER_BOUND = 2;
    public final static int SIZE = 10; // in bytes

    final int score;
    final byte depth, flag;
    final Move bestMove;

    public TTEntry(int score, int depth, int flag, Move bestMove) {
        this.score = score;
        this.depth = (byte)depth;
        this.flag = (byte)flag;
        this.bestMove = bestMove;
    }

    public int score() { return score; }
    public int depth() { return depth; }
    public int flag() { return flag; }
    public Move move() { return bestMove; }
}
