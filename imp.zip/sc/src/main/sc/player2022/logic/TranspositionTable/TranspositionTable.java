package sc.player2022.logic.TranspositionTable;

import java.util.HashMap;

import sc.player2022.logic.Move;

public class TranspositionTable {
    private final static HashMap<Long, TTEntry> table = new HashMap<>();

    public static void set(long key, int score, int flag, int depth, Move bestMove) {
        table.put(key, new TTEntry(score, depth, flag, bestMove));
    }

    public static TTEntry probe(long key) {
        return table.get(key);
    }

    public static void reset() {
        table.clear();
    }
}
