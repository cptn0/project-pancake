package sc.player2022.logic.AI;

import sc.api.plugins.Team;
import sc.player2022.logic.Logic;
import sc.player2022.logic.Board.BitBoard;
import sc.player2022.logic.Board.BitBoard.GameState;
import sc.player2022.logic.Board.BitBoard.GameState.Color;


public class Evaluation {
    static final int COCKLE_VALUE = 100;
    static final int GULL_VALUE = 110;
    static final int STARFISH_VALUE = 120;
    static final int SEAL_VALUE = 150;

    public static int evaluate(int depth) {
        int redEval = 0, blueEval = 0;
        for (int i = 0; i < 8; i++) {
            long pieceBoard = BitBoard.pieceBoards[i];;

            /*
            * Loop through all pieces in the pieceBoard
            */
            while (pieceBoard != 0) {
                int pieceIsolated = Long.numberOfTrailingZeros(pieceBoard & -pieceBoard); // Get the bit position
                long piece = pieceBoard & (1L << pieceIsolated);

                if (i < 4) {
                    redEval += getPieceValue(i) + EvaluationTable.getValue(i, Long.numberOfTrailingZeros(piece) / 8 , Long.numberOfTrailingZeros(piece) % 8);
                } else {
                    blueEval += getPieceValue(i - 4) + EvaluationTable.getValue(i, Long.numberOfTrailingZeros(piece) / 8 , Long.numberOfTrailingZeros(piece) % 8);
                }

                pieceBoard &= pieceBoard - 1; // Get the next piece from the pieceBoard
            }
        }

        redEval += (GameState.score(Color.RED) > 1 ? GameState.score(Color.RED) * 100000 : GameState.score(Color.RED) * 1000);
        blueEval += (GameState.score(Color.BLUE) > 1 ? GameState.score(Color.BLUE) * 100000 : GameState.score(Color.BLUE) * 1000);

        int evaluation = redEval - blueEval;
        return evaluation * (Logic.aiTeam == Team.ONE ? 1 : -1);
    }

    static int getPieceValue(int pieceIndex) {
        switch (pieceIndex) {
            case 0: return COCKLE_VALUE;
            case 1: return GULL_VALUE;
            case 2: return STARFISH_VALUE;
            case 3: return SEAL_VALUE;
            
            default: System.err.println("Something went wrong!"); return 0;
        }
        
    }
}
