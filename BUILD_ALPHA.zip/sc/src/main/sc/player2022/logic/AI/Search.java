package sc.player2022.logic.AI;

import java.util.List;

import sc.player2022.logic.Move;
import sc.player2022.logic.Board.BitBoard;
import sc.player2022.logic.TranspositionTable.TTEntry;
import sc.player2022.logic.TranspositionTable.TranspositionTable;

public class Search {
    static int maxSearchDepth = 99;
    static long startTime;
    static int timeLimit = 1950;
    static boolean timeIsUp = false;
    public final static int INF = 999999;

    private static Move IDMove = null;
    private static int IDScore = 0;
    private static int selDepth;

    public static Move itDeep() {
        startTime = System.currentTimeMillis();
        timeIsUp = false;
        IDMove = null;
        int alpha = -INF;
        int beta = INF;
        int depth = 1;

        for (;; depth++) {
            if (timeIsUp || System.currentTimeMillis() - startTime >= timeLimit) {
                System.out.println("The current depth is: " + depth);
                break;
            }

            negaMaxRoot(depth, alpha, beta);
        }
        return IDMove;
    }

    public static void negaMaxRoot(int depth, int alpha, int beta) {
        int value = -INF;
        List<Move> moves = BitBoard.getPossibleMoves(true);
        if (moves.size() == 1) {
            IDMove = moves.get(0);
            IDScore = 0;
            return;
        }

        Move bestMove = null;
        for (int i = 0; i < moves.size(); i++) {
            Move move = moves.get(i);

            BitBoard.applyMove(move);
            value = -negaMax(depth - 1, 1, -beta, -alpha, true);
            BitBoard.undoMove(move);

            if (timeIsUp || System.currentTimeMillis() - startTime >= timeLimit) {
                timeIsUp = true;
                break;
            }

            if (value > alpha) {
                bestMove = move;
                if (value >= beta) {
                    TranspositionTable.set(BitBoard.hash(), beta, depth, TTEntry.LOWER_BOUND, bestMove);
                    IDMove = bestMove;
                    IDScore = beta;
                    return;
                }
                alpha = value;
                TranspositionTable.set(BitBoard.hash(), alpha, depth, TTEntry.UPPER_BOUND, bestMove);
            }
        }

        if (bestMove == null)
            bestMove = moves.get(0);

        if (!timeIsUp) {
            TranspositionTable.set(BitBoard.hash(), alpha, depth, TTEntry.EXACT, bestMove);
            if (depth % 2 == 0) {
                IDMove = bestMove;
                IDScore = alpha;
            }
        }
    }

    public static int negaMax(int depth, int ply, int alpha, int beta, boolean canApplyNull) {
        int mateValue = INF -ply;

        int ttFlag = TTEntry.UPPER_BOUND;
        int reducedDepth;

        if (timeIsUp || System.currentTimeMillis() - startTime >= timeLimit) {
            timeIsUp = true;
            return 0;
        }

        if (alpha < -mateValue) alpha = -mateValue;
        if (beta > mateValue - 1) beta = mateValue - 1;
        if (alpha >= beta) {
            return alpha;
        }

        if (depth <= 0) return qSearch(depth, ply, alpha, beta);

        final TTEntry ttEntry = TranspositionTable.probe(BitBoard.hash());
        if (ttEntry != null && ttEntry.depth() >= depth) {
            switch (ttEntry.flag()) {
                case TTEntry.EXACT:
                    return ttEntry.score();

                case TTEntry.LOWER_BOUND:
                    alpha = Math.max(alpha, ttEntry.score());
                    break;

                case TTEntry.UPPER_BOUND:
                    beta = Math.min(beta, ttEntry.score());
                    break;
            }

            if (alpha >= beta) {
                return ttEntry.score();
            }
        }

        List<Move> moves = BitBoard.getPossibleMoves(true);
        int value;
        Move bestMove = null;

        for (int i = 0; i < moves.size(); i++) {
            Move move = moves.get(i);

            reducedDepth = depth;

            BitBoard.applyMove(move);
            value = -negaMax(reducedDepth - 1, ply + 1, -beta, -alpha, true);
            BitBoard.undoMove(move);

            if (System.currentTimeMillis() - startTime >= timeLimit) {
                timeIsUp = true;
                return 0;
            }

            if (value > alpha) {
                bestMove = move;
                if (value >= beta) {
                    ttFlag = TTEntry.LOWER_BOUND;
                    alpha = beta;
                    break;
                }
                ttFlag = TTEntry.EXACT;
                alpha = value;
            }
        }

        if (bestMove != null) TranspositionTable.set(BitBoard.hash(), alpha, depth, ttFlag, bestMove);

        return alpha;
    }

    public static int qSearch(int depth, int ply, int alpha, int beta) {
        if (System.currentTimeMillis() - startTime >= timeLimit) {
            timeIsUp = true;
            return 0;
        }

        selDepth = Math.max(ply, selDepth);

        int value = Evaluation.evaluate(depth);

        if (value >= beta) {
            return beta;
        }

        if (alpha < value)
            alpha = value;

        List<Move> moves = BitBoard.getPossibleMoves(false);
        for (int i = 0; i < moves.size(); i++) {
            Move move = moves.get(i);

            BitBoard.applyMove(move);
            value = -qSearch(depth - 1, ply + 1, -beta, -alpha);
            BitBoard.undoMove(move);

            if (System.currentTimeMillis() - startTime >= timeLimit) {
                timeIsUp = true;
                return 0;
            }

            if (value > alpha) {
                if (value >= beta) {
                    return beta;
                }
                alpha = value;
            }
        }
        return alpha;
    }

    public static Move getMove() {
        return IDMove;
    }

    public static int getScore() {
        return IDScore;
    }
}
