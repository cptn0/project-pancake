package sc.player2022.logic;

public class Limits {
    public static long[] time = { Long.MAX_VALUE, Long.MAX_VALUE };
    public static long[] increment = { 0, 0 };
    public static long timeAllocated = Long.MAX_VALUE;
    public static long startTime;
    public static int limitCheckCount = 4096;

    public final static int overhead = 100;

    public static boolean checkLimits() {
        if (--limitCheckCount > 0)
            return false;

        limitCheckCount = 4096;

        long elapsed = System.currentTimeMillis() - startTime;
        return elapsed >= timeAllocated;
    }

    public static void resetTime() {
        time[0] = Long.MAX_VALUE;
        time[1] = Long.MAX_VALUE;
        increment[0] = 0;
        increment[1] = 0;
        timeAllocated = Long.MAX_VALUE;
    }
}
